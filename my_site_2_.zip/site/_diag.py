#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""诊断：确认运行环境."""
import os, sys

print("sys.executable   :", sys.executable)
print("in venv          :", os.environ.get("VIRTUAL_ENV", "(not set)"))

try:
    import flask
    print("flask            :", flask.__version__)
except Exception as e:
    print("flask import FAIL:", e)

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
try:
    import app
    print("import app       : OK")
    print("has init_db      :", hasattr(app, "init_db"))
    print("has app_context  :", hasattr(app.app, "app_context") if hasattr(app, "app") else "no app attr")
except Exception as e:
    print("import app FAIL  :", type(e).__name__, e)
