#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""一键运行所有测试：功能测试 + 持久化验证 + 拆分逻辑 + 导入流程。"""
import subprocess
import sys
import os

HERE = os.path.dirname(os.path.abspath(__file__))


def step(name, script):
    print()
    print("=" * 50)
    print(f"运行 {name}")
    print("=" * 50)
    return subprocess.run([sys.executable, script], cwd=HERE)


def main():
    results = []

    results.append(("test_site.py (功能测试)", step("test_site.py", "test_site.py")))
    results.append(("verify.py (持久化)", step("verify.py", "verify.py")))
    results.append(("test_split.py (章节拆分)", step("test_split.py", "test_split.py")))
    results.append(("test_import.py (导入流程端到端)", step("test_import.py", "test_import.py")))

    print()
    print("=" * 50)
    print("汇总")
    print("=" * 50)
    all_ok = True
    for name, r in results:
        status = "✅ OK" if r.returncode == 0 else "❌ FAIL"
        print(f"  {status}  {name}")
        all_ok = all_ok and (r.returncode == 0)

    if not all_ok:
        print("\n❌ 有测试未通过")
        sys.exit(1)
    print("\n🎉 全部测试通过")


if __name__ == "__main__":
    main()
