# -*- coding: utf-8 -*-
"""端到端验收：Flask test client，独立临时数据库，验证服务启动 + 导入全链路。"""
import os, sys, io, tempfile, shutil
sys.path.insert(0, os.path.dirname(__file__))

# ★ 完全隔离：临时目录放数据库，避免与开发库/重复运行互相污染
TMP = tempfile.mkdtemp(prefix="site_check_")
DB_PATH = os.path.join(TMP, "site.db")
# 若之前跑过（同一次测试内不会，仅为保险），清空
if os.path.exists(DB_PATH):
    os.remove(DB_PATH)

import app as m  # noqa: E402

# 直接替换 Flask 配置中的数据库路径（app.py 不读环境变量，故此处覆盖）
m.app.config["DATABASE"] = DB_PATH
# 保证 instance / upload 目录落在临时区
m.INSTANCE_DIR = TMP
m.UPLOAD_DIR = os.path.join(TMP, "uploads")
os.makedirs(m.UPLOAD_DIR, exist_ok=True)

with m.app.app_context():
    m.init_db()  # 在全新 DB 上建表

c = m.app.test_client()
OK = 0
def check(name, cond):
    global OK
    print(f"  {'✅' if cond else '❌'} {name}")
    OK += bool(cond)

print("▶ 公开路由")
with m.app.app_context():
    db = m.get_db()
    db.execute("INSERT INTO posts(title, body, author_id) VALUES('示例', '内容', 1)")
    db.commit()
r = c.get("/"); check("首页 200", r.status_code == 200)
r = c.get("/novels"); check("小说列表 200", r.status_code == 200)
r = c.get("/search?q=test"); check("搜索页 200", r.status_code == 200)

print("▶ 导入页鉴权")
r = c.get("/admin/novel/import", follow_redirects=False)
check("未登录 → 302 重定向", r.status_code == 302)

print("▶ 上传 md 导入（以 admin 登录）")
with m.app.app_context():
    db = m.get_db()
    db.execute("INSERT INTO users(username, password, is_admin) VALUES('adm', 'x', 1)")
    db.commit()
with c.session_transaction() as s:
    s["user_id"] = 1
    s["username"] = "adm"
    s["is_admin"] = True

# 用 Markdown 风格的「# 第X章」（用户真实场景），验证拆分修复
demo = "# 第一章 开端\n很久很久以前……\n\n# 第二章 转折\n事情发生了变化。\n"
r = c.post("/admin/novel/import", data={
    "file": (io.BytesIO(demo.encode("utf-8")), "book.md"),
    "title": "端到端验收小说",
}, content_type="multipart/form-data", follow_redirects=False)
check(f"上传导入 → 重定向 ({r.status_code})", r.status_code in (302, 200))

with m.app.app_context():
    db = m.get_db()
    novels = db.execute("SELECT * FROM novels WHERE title='端到端验收小说'").fetchall()
    chaps = db.execute("SELECT * FROM chapters").fetchall()
check(f"novels=1 (实际 {len(novels)})", len(novels) == 1)
check(f"chapters=2 (实际 {len(chaps)})", len(chaps) == 2)
if chaps:
    print(f"    章节: {[ (c['number'], c['title']) for c in chaps]}")

print(f"\n结果: {OK}/10 通过")
shutil.rmtree(TMP, ignore_errors=True)
sys.exit(0 if OK == 10 else 1)
