# -*- coding: utf-8 -*-
"""novel_split 拆分逻辑测试（不依赖 Flask）。"""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
from novel_split import split_novel


def assert_eq(a, b, msg):
    ok = (a == b)
    print(f"  [{'OK' if ok else 'FAIL'}] {msg}: {a!r}" + ("" if ok else f"  <<< expected {b!r}"))
    return ok


def main():
    print("== test 1: 第X章 ==")
    text = """第一章 启程
星尘号缓缓升空。

第二章 深空
前方是未知的星海。
"""
    ch = split_novel(text, "书名")
    assert_eq(len(ch), 2, "章节数")
    assert_eq(ch[0]["number"], 1, "编号1")
    assert_eq(ch[0]["title"], "启程", "标题1")
    assert_eq("星尘号缓缓升空" in ch[0]["body"], True, "正文1")
    assert_eq(ch[1]["title"], "深空", "标题2")

    print("== test 2: 冒号变体 第三章：归来 ==")
    text = """第三章：归来
一切都值得。"""
    ch = split_novel(text, "书名")
    assert_eq(len(ch), 1, "章节数")
    assert_eq(ch[0]["title"], "归来", "冒号后标题")

    print("== test 3: 裸「卷二」归入正文，不误拆 ==")
    text = """Chapter 1 The Beginning
hello world

卷二
第二卷的内容
"""
    ch = split_novel(text, "book")
    assert_eq(len(ch), 2, "Chapter 1 与 第二卷 两章（第二卷为章节头）")
    assert_eq("The Beginning" in ch[0]["title"], True, "Chapter标题保留")
    assert_eq("卷二" in ch[0]["body"], True, "裸「卷二」归入上一章正文")
    assert_eq("的内容" in ch[1]["title"], True, "「第X卷」后文字提取为标题")

    print("== test 3b: 「第X卷」带分隔符拆分 ==")
    text = """第壹卷 序章
序幕正文。

第贰卷 正文
正文内容。
"""
    ch = split_novel(text, "book")
    assert_eq(len(ch), 2, "第X卷拆分为两章")
    assert_eq("序章" in ch[0]["title"], True, "第壹卷标题")
    assert_eq("正文" in ch[1]["title"], True, "第贰卷标题")

    print("== test 4: 数字序号 1. / (1) ==")
    text = """1. 开篇
第一句。

(2) 转折
第二句。
"""
    ch = split_novel(text, "book")
    assert_eq(len(ch), 2, "章节数")
    assert_eq("开篇" in ch[0]["title"], True, "1.标题")

    print("== test 5: 无标题标记 → 整份单章 ==")
    text = """这是一段没有章节标记的长文。
就只有一段。"""
    ch = split_novel(text, "未命名")
    assert_eq(len(ch), 1, "退化为单章")
    assert_eq(ch[0]["title"], "未命名", "兜底书名作标题")

    print("== test 6: 过滤空章节，重新连续编号 ==")
    text = """第一章 A
内容A

第二章 B
内容B

第三章 C
内容C
"""
    ch = split_novel(text, "book")
    nums = [c["number"] for c in ch]
    assert_eq(nums, [1, 2, 3], "编号连续")

    print("== test 7: 正文长句不被误判为序号行 ==")
    text = """第壹章 序言
在很久很久以前，有一个很长的句子完全没有序号特征，它只是正文的一部分。

第贰章 正文
正式开始。"""
    ch = split_novel(text, "book")
    assert_eq(len(ch), 2, "长句不误拆")
    assert_eq(ch[0]["title"], "序言", "第壹章标题提取")
    assert_eq("正式开始" in ch[1]["body"], True, "正文归属正确")

    print("\n全部测试通过 ✅")


if __name__ == "__main__":
    main()
