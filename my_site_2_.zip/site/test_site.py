# -*- coding: utf-8 -*-
"""补充：拆分逻辑快速自检，接入既有测试套件。"""
import os, sys
sys.path.insert(0, os.path.dirname(__file__))
from novel_split import split_novel


def test_split_basic():
    ch = split_novel("""第一章 启程
a

第二章 归来
b""", "书")
    assert len(ch) == 2
    assert ch[0]["title"] == "启程"
    assert ch[1]["title"] == "归来"


def test_split_colon():
    ch = split_novel("""第三章：归来
x""", "书")
    assert ch[0]["title"] == "归来"


def test_split_number():
    ch = split_novel("""1. 开篇
a

二、转折
b""", "书")
    assert len(ch) == 2


def test_split_fallback():
    ch = split_novel("一段无标记的长文。", "未命名")
    assert len(ch) == 1 and ch[0]["title"] == "未命名"


if __name__ == "__main__":
    test_split_basic()
    test_split_colon()
    test_split_number()
    test_split_fallback()
    print("novel_split 自检通过 ✅")
