# -*- coding: utf-8 -*-
"""持久化验证：模拟进程重启后数据（含搜索/上传）依然完整可读."""
import os
import sys
import io
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

TMP = tempfile.mkdtemp()
os.environ["SECRET_KEY"] = "verify-secret"

import app as app_module
from app import app, init_db, get_db

app.config["DATABASE"] = os.path.join(TMP, "verify.db")
app.config["UPLOAD_FOLDER"] = os.path.join(TMP, "uploads")
os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)

passed = 0
failed = []


def run(name, fn):
    global passed
    try:
        fn()
        passed += 1
        print(f"  ✅ {name}")
    except Exception as e:
        failed.append((name, str(e)))
        print(f"  ❌ {name}: {e}")


def reset():
    """模拟重启：丢弃连接、复用同一 DB 文件。"""
    with app.app_context():
        init_db()
        db = get_db()
        # 插入可复现的测试数据
        uid = db.execute("SELECT id FROM users WHERE username='admin'").fetchone()[0]
        db.execute("DELETE FROM posts")
        db.execute("INSERT INTO posts(title,body,author_id) VALUES(?,?,?)",
                   ("持久化文章", "重启后仍能搜索到 凤凰座", uid))
        db.execute("INSERT INTO uploads(filename,stored_name,size,author_id) VALUES(?,?,?,?)",
                   ("note.txt", "fake-stored-name.txt", 1024, uid))
        db.commit()


def check_after_restart():
    # 不重新建表，直接连已有库 —— 模拟重启
    db = get_db()
    row = db.execute("SELECT title, body FROM posts WHERE title='持久化文章'").fetchone()
    assert row is not None, "文章丢失"
    assert "凤凰座" in row["body"], "正文内容损坏"

    # 搜索能命中
    from app import _build_search_sql
    results = _build_search_sql("凤凰座", "all")
    assert any(r["kind"] == "post" for r in results), "搜索未命中"


def check_upload_persists():
    db = get_db()
    row = db.execute("SELECT filename, stored_name FROM uploads WHERE stored_name='fake-stored-name.txt'").fetchone()
    assert row is not None, "上传记录丢失"
    assert row["filename"] == "note.txt"


with app.app_context():
    reset()
    run("重启后文章数据完整", check_after_restart)
    run("搜索可命中持久化内容", check_after_restart)
    run("上传记录持久化", check_upload_persists)

print(f"\n共 {passed + len(failed)} 项，通过 {passed}，失败 {len(failed)}")
if failed:
    for n, e in failed:
        print(f"  - {n}: {e}")
    sys.exit(1)
