#!/usr/bin/env bash
# 一键部署脚本
set -e
cd "$(dirname "$0")"

PYTHON="${PYTHON:-python3}"

echo "==> 创建虚拟环境 .venv"
"$PYTHON" -m venv .venv || true
# shellcheck disable=SC1091
source .venv/bin/activate

echo "==> 安装依赖"
pip install --upgrade pip
pip install -r requirements.txt

echo "==> 生成密钥"
if [ ! -f .secret_key ]; then
  python -c "import secrets; open('.secret_key','w').write(secrets.token_hex(32))"
fi
export SECRET_KEY="$(cat .secret_key)"

echo "==> 初始化数据库"
# 用 flask CLI + 显式实例目录，避免 import 路径问题
export FLASK_APP=app.py
export FLASK_ENV=development
# 直接调用 app.py 的 __main__ 块（它内部已做 app_context + init_db）
python -c "
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath('app.py')))
import app
with app.app.app_context():
    app.init_db()
print('DB initialized OK')
"

echo "==> 运行测试（可选，失败不阻断启动）"
"$PYTHON" run_tests.py || true

echo "==> 启动（http://[::]:8080）"
echo "    如需后台运行: nohup python3 app.py > server.log 2>&1 &"
exec python3 app.py
