# -*- coding: utf-8 -*-
"""个人站点 + 小说站：账号体系 / 文章 / 小说章节 / 评论 / 阅读量 / Markdown / 搜索 / 上传."""
import os
import re
import uuid
import sqlite3
from datetime import datetime
from functools import wraps

from flask import (
    Flask, g, render_template, request, redirect, url_for,
    flash, session, abort,
)
import markdown

app = Flask(__name__)

# ---------- 配置 ----------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
INSTANCE_DIR = os.path.join(BASE_DIR, "instance")
UPLOAD_DIR = os.path.join(INSTANCE_DIR, "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)

app.config.update(
    SECRET_KEY=os.environ.get("SECRET_KEY", "dev-secret-change-me"),
    DATABASE=os.path.join(INSTANCE_DIR, "site.db"),
    UPLOAD_FOLDER=UPLOAD_DIR,
    MAX_CONTENT_LENGTH=20 * 1024 * 1024,  # 单文件上限 20MB
)
ALLOWED_EXT = {"png", "jpg", "jpeg", "gif", "webp", "pdf",
               "txt", "md", "docx", "xlsx", "zip", "mp3", "mp4"}


# ---------- 数据库 ----------
def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(app.config["DATABASE"])
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(err):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    db = get_db()
    db.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            is_admin INTEGER DEFAULT 0,
            must_change INTEGER DEFAULT 0,
            created_at TEXT DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS posts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            body TEXT NOT NULL DEFAULT '',
            author_id INTEGER NOT NULL,
            created_at TEXT DEFAULT (datetime('now')),
            views INTEGER DEFAULT 0,
            FOREIGN KEY(author_id) REFERENCES users(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS novels (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            description TEXT NOT NULL DEFAULT '',
            author_id INTEGER NOT NULL,
            created_at TEXT DEFAULT (datetime('now')),
            views INTEGER DEFAULT 0,
            FOREIGN KEY(author_id) REFERENCES users(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS chapters (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            novel_id INTEGER NOT NULL,
            number INTEGER NOT NULL,
            title TEXT NOT NULL,
            body TEXT NOT NULL DEFAULT '',
            created_at TEXT DEFAULT (datetime('now')),
            views INTEGER DEFAULT 0,
            FOREIGN KEY(novel_id) REFERENCES novels(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS comments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            target_type TEXT NOT NULL,
            target_id INTEGER NOT NULL,
            author_id INTEGER NOT NULL,
            body TEXT NOT NULL,
            created_at TEXT DEFAULT (datetime('now')),
            FOREIGN KEY(author_id) REFERENCES users(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS uploads (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            filename TEXT NOT NULL,
            stored_name TEXT NOT NULL UNIQUE,
            mime TEXT,
            size INTEGER,
            author_id INTEGER NOT NULL,
            created_at TEXT DEFAULT (datetime('now')),
            FOREIGN KEY(author_id) REFERENCES users(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_posts_title ON posts(title);
        CREATE INDEX IF NOT EXISTS idx_posts_body ON posts(body);
        CREATE INDEX IF NOT EXISTS idx_novels_title ON novels(title);
        CREATE INDEX IF NOT EXISTS idx_chapters_title ON chapters(title);
        CREATE INDEX IF NOT EXISTS idx_chapters_body ON chapters(body);
    """)
    # 默认管理员
    try:
        db.execute(
            "INSERT INTO users(username, password, is_admin, must_change) VALUES(?,?,?,?)",
            ("admin", "admin123", 1, 1),
        )
        db.commit()
    except sqlite3.IntegrityError:
        pass
    # 示例数据
    if not db.execute("SELECT 1 FROM posts LIMIT 1").fetchone():
        uid = db.execute("SELECT id FROM users WHERE username='admin'").fetchone()[0]
        db.execute("INSERT INTO posts(title,body,author_id) VALUES(?,?,?)",
                   ("欢迎来到我的站点", "这是第一篇文章，支持 **Markdown**。", uid))
        db.execute("INSERT INTO posts(title,body,author_id) VALUES(?,?,?)",
                   ("Flask 搭建小站指南", "使用 `python -m flask run` 即可启动开发服务器。", uid))
        if not db.execute("SELECT 1 FROM novels LIMIT 1").fetchone():
            cur = db.execute("INSERT INTO novels(title,description,author_id) VALUES(?,?,?)",
                             ("星尘之旅", "一部关于宇宙探索的科幻小说。", uid))
            nid = cur.lastrowid
            db.execute("INSERT INTO chapters(novel_id,number,title,body) VALUES(?,?,?,?)",
                       (nid, 1, "第一章 启程", "星尘号缓缓升空……"))
            db.execute("INSERT INTO chapters(novel_id,number,title,body) VALUES(?,?,?,?)",
                       (nid, 2, "第二章 深空", "前方是未知的星海。"))
        db.commit()


@app.before_request
def ensure_db():
    get_db()


@app.cli.command("init-db")
def init_db_cmd():
    init_db()
    print("数据库已初始化")


# ---------- 工具 ----------
def login_required(f):
    @wraps(f)
    def w(*a, **kw):
        if "user_id" not in session:
            flash("请先登录", "warning")
            return redirect(url_for("login", next=request.path))
        return f(*a, **kw)
    return w


def admin_required(f):
    @wraps(f)
    def w(*a, **kw):
        if not session.get("is_admin"):
            flash("需要管理员权限", "danger")
            return redirect(url_for("index"))
        return f(*a, **kw)
    return w


@app.template_filter("md")
def md_filter(text):
    if not text:
        return ""
    return markdown.markdown(text, extensions=["fenced_code", "tables", "nl2br"])


@app.context_processor
def inject_user():
    return dict(
        current_user=_current_user(),
        site_name="我的小站",
    )


def _current_user():
    if "user_id" not in session:
        return None
    row = get_db().execute("SELECT * FROM users WHERE id=?", (session["user_id"],)).fetchone()
    return row


def _row_to_dict(row):
    return dict(row) if row else None


# ---------- 搜索 ----------
def _build_search_sql(q, scope):
    """按范围构造搜索 SQL，返回 (sql, params, 结果类型)."""
    like = f"%{q}%"
    results = []
    db = get_db()
    if scope in ("all", "posts"):
        rows = db.execute(
            "SELECT id, title, body, 'post' AS kind, created_at FROM posts "
            "WHERE title LIKE ? OR body LIKE ? ORDER BY created_at DESC LIMIT 50",
            (like, like),
        ).fetchall()
        results.extend([dict(r) for r in rows])
    if scope in ("all", "novels"):
        rows = db.execute(
            "SELECT n.id, n.title, n.description AS body, 'novel' AS kind, n.created_at "
            "FROM novels n WHERE n.title LIKE ? OR n.description LIKE ? "
            "ORDER BY n.created_at DESC LIMIT 50", (like, like)).fetchall()
        results.extend([dict(r) for r in rows])
    if scope in ("all", "chapters"):
        rows = db.execute(
            "SELECT c.id, c.title, c.body, 'chapter' AS kind, c.novel_id, n.title AS novel_title, c.created_at "
            "FROM chapters c JOIN novels n ON n.id=c.novel_id "
            "WHERE c.title LIKE ? OR c.body LIKE ? ORDER BY c.created_at DESC LIMIT 50",
            (like, like),
        ).fetchall()
        results.extend([dict(r) for r in rows])
    return results


@app.route("/search")
def search():
    q = (request.args.get("q") or "").strip()
    scope = request.args.get("scope", "all")
    if not q:
        return render_template("search.html", results=[], q="", scope=scope)
    if len(q) < 2:
        flash("搜索关键词至少 2 个字符", "warning")
        return render_template("search.html", results=[], q=q, scope=scope)
    results = _build_search_sql(q, scope)
    return render_template("search.html", results=results, q=q, scope=scope,
                           now=datetime.utcnow)


# ---------- 首页 / 文章 ----------
@app.route("/")
def index():
    db = get_db()
    posts = db.execute(
        "SELECT p.*, u.username FROM posts p JOIN users u ON u.id=p.author_id "
        "ORDER BY p.created_at DESC LIMIT 20").fetchall()
    novels = db.execute(
        "SELECT n.*, u.username FROM novels n JOIN users u ON u.id=n.author_id "
        "ORDER BY n.created_at DESC LIMIT 10").fetchall()
    return render_template("index.html", posts=posts, novels=novels)


@app.route("/post/new", methods=("GET", "POST"))
@login_required
def post_new():
    if request.method == "POST":
        title = (request.form.get("title") or "").strip()
        body = request.form.get("body", "")
        if not title:
            flash("标题不能为空", "danger")
        else:
            db = get_db()
            db.execute("INSERT INTO posts(title, body, author_id) VALUES(?,?,?)",
                       (title, body, session["user_id"]))
            db.commit()
            flash("文章已发布", "success")
            return redirect(url_for("index"))
    return render_template("editor.html", kind="post", item=None)


@app.route("/post/<int:post_id>")
def post_detail(post_id):
    db = get_db()
    post = db.execute(
        "SELECT p.*, u.username FROM posts p JOIN users u ON u.id=p.author_id WHERE p.id=?",
        (post_id,)).fetchone()
    if not post:
        abort(404)
    db.execute("UPDATE posts SET views=views+1 WHERE id=?", (post_id,))
    comments = db.execute(
        "SELECT c.*, u.username FROM comments c JOIN users u ON u.id=c.author_id "
        "WHERE c.target_type='post' AND c.target_id=? ORDER BY c.created_at DESC",
        (post_id,)).fetchall()
    db.commit()
    return render_template("detail.html", post=post, comments=comments)


@app.route("/post/<int:post_id>/edit", methods=("GET", "POST"))
@login_required
def post_edit(post_id):
    db = get_db()
    post = db.execute("SELECT * FROM posts WHERE id=?", (post_id,)).fetchone()
    if not post:
        abort(404)
    if post["author_id"] != session["user_id"] and not session.get("is_admin"):
        flash("只能编辑自己的文章", "danger")
        return redirect(url_for("index"))
    if request.method == "POST":
        title = (request.form.get("title") or "").strip()
        body = request.form.get("body", "")
        if not title:
            flash("标题不能为空", "danger")
        else:
            db.execute("UPDATE posts SET title=?, body=? WHERE id=?", (title, body, post_id))
            db.commit()
            flash("文章已更新", "success")
            return redirect(url_for("post_detail", post_id=post_id))
    return render_template("editor.html", kind="post", item=post)


@app.route("/post/<int:post_id>/delete", methods=("POST",))
@login_required
def post_delete(post_id):
    db = get_db()
    post = db.execute("SELECT author_id FROM posts WHERE id=?", (post_id,)).fetchone()
    if not post:
        abort(404)
    if post["author_id"] != session["user_id"] and not session.get("is_admin"):
        flash("无权删除", "danger")
        return redirect(url_for("index"))
    db.execute("DELETE FROM posts WHERE id=?", (post_id,))
    db.execute("DELETE FROM comments WHERE target_type='post' AND target_id=?", (post_id,))
    db.commit()
    flash("文章已删除", "success")
    return redirect(url_for("index"))


# ---------- 评论 ----------
@app.route("/comment/<target_type>/<int:target_id>", methods=("POST",))
@login_required
def add_comment(target_type, target_id):
    if target_type not in ("post", "novel", "chapter"):
        abort(400)
    body = (request.form.get("body") or "").strip()
    if not body:
        flash("评论内容不能为空", "warning")
        return redirect(request.referrer or url_for("index"))
    db = get_db()
    db.execute("INSERT INTO comments(target_type, target_id, author_id, body) VALUES(?,?,?,?)",
               (target_type, target_id, session["user_id"], body))
    db.commit()
    flash("评论成功", "success")
    return redirect(request.referrer or url_for("index"))


# ---------- 小说 ----------
@app.route("/novels")
def novel_list():
    db = get_db()
    novels = db.execute(
        "SELECT n.*, u.username FROM novels n JOIN users u ON u.id=n.author_id "
        "ORDER BY n.created_at DESC").fetchall()
    return render_template("novels.html", novels=novels)


@app.route("/novel/<int:novel_id>")
def novel_detail(novel_id):
    db = get_db()
    novel = db.execute("SELECT * FROM novels WHERE id=?", (novel_id,)).fetchone()
    if not novel:
        abort(404)
    db.execute("UPDATE novels SET views=views+1 WHERE id=?", (novel_id,))
    chapters = db.execute(
        "SELECT * FROM chapters WHERE novel_id=? ORDER BY number ASC, id ASC",
        (novel_id,)).fetchall()
    comments = db.execute(
        "SELECT c.*, u.username FROM comments c JOIN users u ON u.id=c.author_id "
        "WHERE c.target_type='novel' AND c.target_id=? ORDER BY c.created_at DESC",
        (novel_id,)).fetchall()
    db.commit()
    return render_template("novel_detail.html", novel=novel, chapters=chapters, comments=comments)


@app.route("/novel/<int:novel_id>/chapter/<int:chapter_id>")
def chapter_read(novel_id, chapter_id):
    db = get_db()
    chapter = db.execute(
        "SELECT c.*, n.title AS novel_title FROM chapters c JOIN novels n ON n.id=c.novel_id "
        "WHERE c.id=? AND c.novel_id=?", (chapter_id, novel_id)).fetchone()
    if not chapter:
        abort(404)
    db.execute("UPDATE chapters SET views=views+1 WHERE id=?", (chapter_id,))
    total = db.execute("SELECT COUNT(*) FROM chapters WHERE novel_id=?", (novel_id,)).fetchone()[0]
    db.commit()
    return render_template("chapter.html", chapter=chapter, total=total)


@app.route("/admin/novels")
@admin_required
def admin_novels():
    db = get_db()
    novels = db.execute("SELECT * FROM novels ORDER BY created_at DESC").fetchall()
    return render_template("admin_novels.html", novels=novels)


@app.route("/admin/novel/new", methods=("GET", "POST"))
@admin_required
def novel_new():
    if request.method == "POST":
        title = (request.form.get("title") or "").strip()
        desc = request.form.get("description", "")
        if not title:
            flash("标题不能为空", "danger")
        else:
            db = get_db()
            db.execute("INSERT INTO novels(title, description, author_id) VALUES(?,?,?)",
                       (title, desc, session["user_id"]))
            db.commit()
            flash("小说已创建", "success")
            return redirect(url_for("admin_novels"))
    return render_template("editor.html", kind="novel", item=None)


@app.route("/admin/novel/<int:novel_id>/edit", methods=("GET", "POST"))
@admin_required
def novel_edit(novel_id):
    db = get_db()
    novel = db.execute("SELECT * FROM novels WHERE id=?", (novel_id,)).fetchone()
    if not novel:
        abort(404)
    if request.method == "POST":
        title = (request.form.get("title") or "").strip()
        desc = request.form.get("description", "")
        if not title:
            flash("标题不能为空", "danger")
        else:
            db.execute("UPDATE novels SET title=?, description=? WHERE id=?", (title, desc, novel_id))
            db.commit()
            flash("小说已更新", "success")
            return redirect(url_for("admin_novels"))
    return render_template("editor.html", kind="novel", item=novel)


@app.route("/admin/novel/<int:novel_id>/chapter/new", methods=("GET", "POST"))
@admin_required
def chapter_new(novel_id):
    db = get_db()
    novel = db.execute("SELECT * FROM novels WHERE id=?", (novel_id,)).fetchone()
    if not novel:
        abort(404)
    if request.method == "POST":
        number = int(request.form.get("number") or 0)
        title = (request.form.get("title") or "").strip()
        body = request.form.get("body", "")
        if not title:
            flash("章节标题不能为空", "danger")
        else:
            db.execute("INSERT INTO chapters(novel_id,number,title,body) VALUES(?,?,?,?)",
                       (novel_id, number, title, body))
            db.commit()
            flash("章节已添加", "success")
            return redirect(url_for("novel_detail", novel_id=novel_id))
    return render_template("editor.html", kind="chapter", item=None, novel=novel)


@app.route("/admin/chapter/<int:chapter_id>/edit", methods=("GET", "POST"))
@admin_required
def chapter_edit(chapter_id):
    db = get_db()
    chapter = db.execute("SELECT * FROM chapters WHERE id=?", (chapter_id,)).fetchone()
    if not chapter:
        abort(404)
    if request.method == "POST":
        number = int(request.form.get("number") or 0)
        title = (request.form.get("title") or "").strip()
        body = request.form.get("body", "")
        if not title:
            flash("章节标题不能为空", "danger")
        else:
            db.execute("UPDATE chapters SET number=?, title=?, body=? WHERE id=?",
                       (number, title, body, chapter_id))
            db.commit()
            flash("章节已更新", "success")
            return redirect(url_for("novel_detail", novel_id=chapter["novel_id"]))
    return render_template("editor.html", kind="chapter", item=chapter)


# ---------- 文件上传 ----------
def _allowed(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXT


def _safe_filename(name):
    name = re.sub(r"[^\w\u4e00-\u9fa5.]+", "_", name).strip("._")
    return name or "file"


@app.route("/upload", methods=("GET", "POST"))
@login_required
def upload():
    db = get_db()
    if request.method == "POST":
        f = request.files.get("file")
        if not f or not f.filename:
            flash("请选择文件", "warning")
            return redirect(url_for("upload"))
        if not _allowed(f.filename):
            flash(f"不支持的文件类型，允许：{', '.join(sorted(ALLOWED_EXT))}", "danger")
            return redirect(url_for("upload"))
        orig = _safe_filename(f.filename)
        ext = orig.rsplit(".", 1)[-1].lower() if "." in orig else ""
        stored = f"{uuid.uuid4().hex}.{ext}" if ext else f"{uuid.uuid4().hex}"
        f.save(os.path.join(app.config["UPLOAD_FOLDER"], stored))
        db.execute(
            "INSERT INTO uploads(filename, stored_name, mime, size, author_id) VALUES(?,?,?,?,?)",
            (orig, stored, f.content_type, getattr(f, "content_length", 0) or 0,
             session["user_id"]))
        db.commit()
        flash(f"上传成功：{orig}", "success")
        return redirect(url_for("upload"))
    files = db.execute(
        "SELECT u.*, us.username FROM uploads u JOIN users us ON us.id=u.author_id "
        "ORDER BY u.created_at DESC LIMIT 50").fetchall()
    return render_template("upload.html", files=files)


@app.route("/uploads/<stored_name>")
def serve_upload(stored_name):
    """提供文件下载（真实部署建议用 Nginx/X-Accel 托管，此处为演示）。"""
    db = get_db()
    row = db.execute("SELECT stored_name, filename FROM uploads WHERE stored_name=?",
                     (stored_name,)).fetchone()
    if not row:
        abort(404)
    directory = app.config["UPLOAD_FOLDER"]
    from flask import send_from_directory
    return send_from_directory(directory, row["stored_name"],
                               download_name=row["filename"], as_attachment=True)


@app.route("/upload/<int:file_id>/delete", methods=("POST",))
@login_required
def upload_delete(file_id):
    db = get_db()
    row = db.execute("SELECT stored_name, author_id FROM uploads WHERE id=?", (file_id,)).fetchone()
    if not row:
        abort(404)
    if row["author_id"] != session["user_id"] and not session.get("is_admin"):
        flash("无权删除", "danger")
        return redirect(url_for("upload"))
    path = os.path.join(app.config["UPLOAD_FOLDER"], row["stored_name"])
    if os.path.exists(path):
        os.remove(path)
    db.execute("DELETE FROM uploads WHERE id=?", (file_id,))
    db.commit()
    flash("文件已删除", "success")
    return redirect(url_for("upload"))


# ---------- 认证 ----------
@app.route("/register", methods=("GET", "POST"))
def register():
    if request.method == "POST":
        username = (request.form.get("username") or "").strip()
        password = request.form.get("password", "")
        if len(username) < 2 or len(password) < 6:
            flash("用户名至少2字符，密码至少6位", "danger")
        else:
            try:
                db = get_db()
                cur = db.execute("INSERT INTO users(username, password) VALUES(?,?)",
                                 (username, password))
                db.commit()
                session["user_id"] = cur.lastrowid
                flash("注册成功，已自动登录", "success")
                return redirect(url_for("index"))
            except sqlite3.IntegrityError:
                flash("用户名已被占用", "danger")
    return render_template("register.html")


@app.route("/login", methods=("GET", "POST"))
def login():
    if request.method == "POST":
        username = request.form.get("username", "")
        password = request.form.get("password", "")
        row = get_db().execute("SELECT * FROM users WHERE username=? AND password=?",
                               (username, password)).fetchone()
        if row:
            session["user_id"] = row["id"]
            session["is_admin"] = bool(row["is_admin"])
            session["username"] = row["username"]
            if row["must_change"]:
                flash("首次登录，请修改密码", "warning")
                return redirect(url_for("change_password"))
            flash(f"欢迎回来，{row['username']}", "success")
            return redirect(request.args.get("next") or url_for("index"))
        flash("用户名或密码错误", "danger")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("已退出登录", "info")
    return redirect(url_for("index"))


@app.route("/change-password", methods=("GET", "POST"))
@login_required
def change_password():
    if request.method == "POST":
        new = request.form.get("new_password", "")
        confirm = request.form.get("confirm", "")
        if len(new) < 6:
            flash("密码至少6位", "danger")
        elif new != confirm:
            flash("两次输入不一致", "danger")
        else:
            db = get_db()
            db.execute("UPDATE users SET password=?, must_change=0 WHERE id=?",
                       (new, session["user_id"]))
            db.commit()
            flash("密码已更新", "success")
            return redirect(url_for("index"))
    return render_template("change_password.html")


# ---------- 小说导入（上传 txt/md 自动拆章节） ----------
from novel_import import bp as novel_import_bp
app.register_blueprint(novel_import_bp)


# ---------- 错误页 ----------
@app.errorhandler(404)
def not_found(e):
    return render_template("404.html"), 404


if __name__ == "__main__":
    with app.app_context():
        init_db()
    app.run(host="::", port=8080, debug=True)
