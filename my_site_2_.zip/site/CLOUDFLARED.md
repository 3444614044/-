# Cloudflare Tunnel 部署指南（免公网端口 + 自动 HTTPS）

不开放任何公网端口，外部流量经 Cloudflare 转发到本机 8080。

## 1. 安装 cloudflared

- 官网：https://developers.cloudflare.com/cloudflare-one/connections/connect-networks/downloads/
- Termux：`pkg install cloudflared` 或下载 arm64 二进制

## 2. 登录并创建隧道

```bash
cloudflared tunnel login          # 浏览器授权域名
cloudflared tunnel create my-site # 生成隧道 + 凭据文件
```

记下输出的凭据路径，例如：
`/root/.cloudflared/xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx.json`

## 3. 配置隧道（config.yml）

```yaml
tunnel: xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
credentials-file: /root/.cloudflared/xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx.json

ingress:
  - hostname: your-domain.example.com
    service: http://localhost:8080
  - service: http_status:404
```

## 4. 绑定域名 + 启动

```bash
cloudflared tunnel route dns my-site your-domain.example.com
cloudflared tunnel --config config.yml run my-site
```

等待几十秒，访问 `https://your-domain.example.com` 即可（自动 HTTPS）。

## 5. 设为系统服务（可选）

```bash
cloudflared service install --config /path/to/config.yml
```

## 说明

- 无需公网 IPv4/IPv6 端口开放，绕过运营商防火墙
- Cloudflare 提供免费 HTTPS 证书 + DDoS 防护
- 本地 8080 仍由 gunicorn 监听，仅回环/本地访问即可
- 想停用：停止隧道进程 + `cloudflared tunnel route dns my-site --delete`
