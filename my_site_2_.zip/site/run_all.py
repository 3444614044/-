# -*- coding: utf-8 -*-
"""一键跑全部测试：拆分逻辑 + 导入流程 + 原有功能回归。"""
import os, sys, subprocess

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

passed = []
failed = []


def run(name, fn):
    print("=" * 50)
    print(f"▶ {name}")
    try:
        fn()
        passed.append(name)
        print(f"✅ {name} 通过")
    except AssertionError as e:
        failed.append((name, str(e)))
        print(f"❌ {name} 失败: {e}")
    except Exception as e:
        failed.append((name, repr(e)))
        print(f"❌ {name} 异常: {e}")


def t_split():
    from novel_split import split_novel
    ch = split_novel("""第一章 启程
内容A。

第二章 归来
内容B。""", "书")
    assert len(ch) == 2, len(ch)
    assert ch[0]["title"] == "启程", ch[0]["title"]
    assert ch[1]["title"] == "归来", ch[1]["title"]
    # 冒号变体
    ch = split_novel("""第三章：归来
x""", "书")
    assert ch[0]["title"] == "归来", ch[0]["title"]
    # 数字序号
    ch = split_novel("""1. 开篇
a

二、转折
b""", "书")
    assert len(ch) == 2, ch
    # 兜底单章
    ch = split_novel("一段无标记的长文。", "未命名")
    assert len(ch) == 1 and ch[0]["title"] == "未命名", ch


def t_import():
    import tempfile
    tmp = tempfile.mkdtemp()
    os.environ["DATABASE"] = os.path.join(tmp, "t.db")
    # 每次重新 import 拿到干净 app
    for mod in [m for m in list(sys.modules) if m in ("app", "novel_import")]:
        del sys.modules[mod]
    import io
    import app as appmod
    from app import app, init_db, get_db
    app.config["TESTING"] = True
    with app.app_context():
        init_db()
    c = app.test_client()
    # 登录 admin
    r = c.post("/login", data={"username": "admin", "password": "admin123"}, follow_redirects=True)
    assert r.status_code == 200, r.status_code
    # 上传
    text = """第一章 A
正文A。

第二章 B
正文B。"""
    data = {"file": (io.BytesIO(text.encode()), "book.md"), "title": "测试导入书"}
    r = c.post("/admin/novel/import", data=data, content_type="multipart/form-data", follow_redirects=False)
    assert r.status_code == 302, (r.status_code, r.data[:200])
    # 查库
    with app.app_context():
        db = get_db()
        novel = db.execute("SELECT * FROM novels WHERE title=?", ("测试导入书",)).fetchone()
        assert novel is not None, "小说未入库"
        ch = db.execute("SELECT COUNT(*) c FROM chapters WHERE novel_id=?", (novel["id"],)).fetchone()
        assert ch["c"] == 2, ch["c"]
    # 前端可读
    with app.app_context():
        nid = get_db().execute("SELECT id FROM novels WHERE title=?", ("测试导入书",)).fetchone()["id"]
    r = c.get(f"/novel/{nid}")
    assert r.status_code == 200, r.status_code
    # 异常：错误格式
    data2 = {"file": (io.BytesIO(b"x"), "bad.exe")}
    r = c.post("/admin/novel/import", data=data2, content_type="multipart/form-data", follow_redirects=True)
    assert r.status_code == 200, r.status_code
    # 权限：未登录
    c2 = app.test_client()
    r = c2.get("/admin/novel/import", follow_redirects=False)
    assert r.status_code == 302, r.status_code


def t_regression():
    """原有功能回归：首页 / 文章 / 小说列表 / 搜索。"""
    import tempfile
    tmp = tempfile.mkdtemp()
    os.environ["DATABASE"] = os.path.join(tmp, "r.db")
    for mod in [m for m in list(sys.modules) if m in ("app", "novel_import")]:
        del sys.modules[mod]
    import app as appmod
    from app import app, init_db
    app.config["TESTING"] = True
    with app.app_context():
        init_db()
    c = app.test_client()
    assert c.get("/").status_code == 200
    assert c.get("/novels").status_code == 200
    r = c.get("/search?q=星尘&scope=all", follow_redirects=True)
    assert r.status_code == 200, r.status_code
    # 登录 + 发文章
    c.post("/login", data={"username": "admin", "password": "admin123"}, follow_redirects=True)
    r = c.post("/post/new", data={"title": "导入功能测试文章", "body": "正文"}, follow_redirects=True)
    assert r.status_code == 200, r.status_code
    assert "导入功能测试文章".encode() in r.data, "文章发布后在首页可见"


run("拆分逻辑 (novel_split)", t_split)
run("导入流程 (上传→拆章节→入库→可读)", t_import)
run("原有功能回归 (首页/小说/搜索/文章)", t_regression)

print("\n" + "=" * 50)
print(f"总计：{len(passed)} 通过，{len(failed)} 失败")
if failed:
    for n, e in failed:
        print(f"  ❌ {n}: {e}")
    sys.exit(1)
print("🎉 全部通过")
