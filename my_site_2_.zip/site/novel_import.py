# -*- coding: utf-8 -*-
"""「上传 txt/md 自动拆章节建小说」路由。

挂载：在 app.py 里已加：
    from novel_import import bp as novel_import_bp
    app.register_blueprint(novel_import_bp)

权限：沿用项目约定 —— 仅管理员可用（未登录/非 admin 重定向首页）。
"""
from flask import (
    Blueprint, request, redirect, url_for, flash, render_template, session,
)

bp = Blueprint("novel_import", __name__)


def _get_db():
    # 延迟导入，避免与 app.py 循环导入（get_db 定义在 app.py）
    from app import get_db
    return get_db()

ALLOWED = {"txt", "md", "markdown", "text"}


@bp.route("/admin/novel/import", methods=("GET", "POST"))
def novel_import():
    # 未登录 / 非管理员 → 重定向首页（与原项目 admin_required 行为一致）
    if not session.get("is_admin"):
        flash("需要管理员权限", "danger")
        return redirect(url_for("index"))

    if request.method == "POST":
        f = request.files.get("file")
        title = (request.form.get("title") or "").strip()
        description = (request.form.get("description") or "").strip()
        if not f or not f.filename:
            flash("请选择小说文件（.txt 或 .md）", "warning")
            return redirect(request.url)
        ext = f.filename.rsplit(".", 1)[-1].lower() if "." in f.filename else ""
        if ext not in ALLOWED:
            flash(f"仅支持 {sorted(ALLOWED)} 格式，当前是 .{ext}", "danger")
            return redirect(request.url)

        text = f.read().decode("utf-8", errors="ignore")
        if not text.strip():
            flash("文件内容为空", "danger")
            return redirect(request.url)

        from novel_split import split_novel
        chapters = split_novel(text, fallback_title=title or f.filename)

        if not chapters:
            flash("未能从文件中解析出任何内容", "danger")
            return redirect(request.url)

        # 书名兜底：优先用表单填写的，否则取首章标题
        book_title = title or chapters[0]["title"] or "未命名小说"

        db = _get_db()
        cur = db.execute(
            "INSERT INTO novels(title, description, author_id) VALUES(?,?,?)",
            (book_title, description, session["user_id"]),
        )
        novel_id = cur.lastrowid
        for ch in chapters:
            db.execute(
                "INSERT INTO chapters(novel_id, number, title, body) VALUES(?,?,?,?)",
                (novel_id, ch["number"], ch["title"], ch["body"]),
            )
        db.commit()
        flash(f"导入成功：共 {len(chapters)} 章", "success")
        return redirect(url_for("novel_detail", novel_id=novel_id))

    return render_template("novel_import.html")
