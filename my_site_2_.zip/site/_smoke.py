#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""验证部署关键步骤：import + init_db 能否成功。

说明：本项目 `import app` 得到的是模块对象（module），
Flask 应用实例存在模块属性 `app.app` 上，因此上下文/配置一律用 `app.app`。
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import app as appmod

flask_app = appmod.app  # Flask 应用实例

print("import app          : OK")
print("has init_db         :", hasattr(appmod, "init_db"))
print("has app.app_context :", hasattr(flask_app, "app_context"))

assert hasattr(appmod, "init_db") and hasattr(flask_app, "app_context")

with flask_app.app_context():
    appmod.init_db()
print("init_db()           : OK")

# 确认表都建出来了
import sqlite3
db = sqlite3.connect(flask_app.config["DATABASE"])
rows = db.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name").fetchall()
print("tables created      :", [r[0] for r in rows])
db.close()
