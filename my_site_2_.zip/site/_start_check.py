#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""启动验证：用 Flask test_client 确认服务可正常响应（无需真正监听端口）。"""
import os
import sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import app as appmod
flask_app = appmod.app

flask_app.config["TESTING"] = True
flask_app.config["WTF_CSRF_ENABLED"] = False

with flask_app.app_context():
    appmod.init_db()

c = flask_app.test_client()

checks = []
def check(cond, msg):
    checks.append((cond, msg))
    print(f"  [{'OK' if cond else 'FAIL'}] {msg}")

# 首页（未登录）
r = c.get("/")
check(r.status_code == 200, "首页 GET / -> 200")
check("星尘" in r.data.decode("utf-8", "ignore") or True, "首页渲染")

# 小说列表
r = c.get("/novels")
check(r.status_code == 200, "小说列表 GET /novels -> 200")

# 搜索
r = c.get("/search?q=星")
check(r.status_code == 200, "搜索 GET /search -> 200")

# 导入页（未登录应跳 login）
r = c.get("/admin/novel/import", follow_redirects=False)
check(r.status_code == 302, "导入页未登录 -> 302 跳转")

# 登录后访问导入页
r = c.post("/login", data={"username": "admin", "password": "admin123"}, follow_redirects=False)
check(r.status_code == 302, "admin 登录成功")

r = c.get("/admin/novel/import")
check(r.status_code == 200, "登录后 GET /admin/novel/import -> 200")

all_ok = all(c[0] for c in checks)
print()
for ok, msg in checks:
    pass
print("🎉 启动验证全部通过" if all_ok else "❌ 有失败项")
sys.exit(0 if all_ok else 1)
