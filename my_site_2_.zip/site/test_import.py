# -*- coding: utf-8 -*-
"""端到端：用 Flask test_client 模拟「上传 txt → 自动拆章节 → 入库 → 可读」。

直接 import app（模块里的 Flask 实例），无需运行服务器。
"""
import os, sys, io
sys.path.insert(0, os.path.dirname(__file__))

# 用独立临时数据库，不污染 site.db
import tempfile
tmp = tempfile.mkdtemp()
os.environ["DATABASE"] = os.path.join(tmp, "test.db")

import app as appmod
from app import app, init_db, get_db

app.config["TESTING"] = True
app.config["WTF_CSRF_ENABLED"] = False


def check(cond, msg):
    print(f"  [{'OK' if cond else 'FAIL'}] {msg}")
    return cond


def main():
    with app.app_context():
        init_db()

    c = app.test_client()

    # 先登录 admin（明文密码 admin123）
    print("== 登录 admin ==")
    r = c.post("/login", data={"username": "admin", "password": "admin123"}, follow_redirects=False)
    check(r.status_code == 302, "登录后跳转")

    # GET 导入页
    print("== GET /admin/novel/import ==")
    r = c.get("/admin/novel/import")
    check(r.status_code == 200, "导入页可访问")
    check("导入小说" in r.data.decode("utf-8", "ignore"), "页面含标题")

    # 准备一本小说文件（用 第X章 格式）
    novel_text = """第一章 启程
星尘号缓缓升空。

第二章 深空
前方是未知的星海。

第三章：归来
一切都值得。
"""
    data = {
        "file": (io.BytesIO(novel_text.encode("utf-8")), "xingchen.md"),
        "title": "星尘之旅（导入）",
        "description": "自动导入测试",
    }
    print("== POST 上传文件 ==")
    r = c.post("/admin/novel/import", data=data, content_type="multipart/form-data", follow_redirects=False)
    check(r.status_code == 302, "导入后跳转")
    # 应跳到 novel_detail
    check("/novel/" in r.headers.get("Location", ""), "跳转到小说详情")

    # 验证数据库内容
    print("== 校验数据库 ==")
    with app.app_context():
        db = get_db()
        novel = db.execute("SELECT * FROM novels WHERE title=?", ("星尘之旅（导入）",)).fetchone()
        check(novel is not None, "小说已入库")
        chapters = db.execute("SELECT * FROM chapters WHERE novel_id=? ORDER BY number", (novel["id"],)).fetchall()
        check(len(chapters) == 3, f"共 3 章（实际 {len(chapters)}）")
        check(chapters[0]["title"] == "启程", "第1章标题")
        check(chapters[1]["title"] == "深空", "第2章标题")
        check(chapters[2]["title"] == "归来", "第3章（冒号变体）标题")
        check("星尘号缓缓升空" in chapters[0]["body"], "第1章正文入库")

    # 验证前端可读（novel_detail + chapter 页）
    print("== 前端可读 ==")
    with app.app_context():
        nid = get_db().execute("SELECT id FROM novels WHERE title=?", ("星尘之旅（导入）",)).fetchone()["id"]
    r = c.get(f"/novel/{nid}")
    check(r.status_code == 200, "小说详情页 200")
    check("星尘之旅（导入）".encode("utf-8") in r.data, "详情页显示书名")
    with app.app_context():
        cid = get_db().execute("SELECT id FROM chapters WHERE novel_id=?", (nid,)).fetchone()["id"]
    r = c.get(f"/novel/{nid}/chapter/{cid}")
    check(r.status_code == 200, "章节阅读页 200")
    check("星尘号缓缓升空".encode("utf-8") in r.data, "章节正文渲染")

    # 异常：传非允许格式
    print("== 异常：不支持的格式 ==")
    data2 = {"file": (io.BytesIO(b"not a novel"), "evil.exe")}
    r = c.post("/admin/novel/import", data=data2, content_type="multipart/form-data", follow_redirects=True)
    check(r.status_code == 200, "拒绝 exe，回到表单页")
    body = r.data.decode("utf-8", "ignore")
    check(("仅支持" in body) or ("请选择" in body), "给出错误提示")

    # 权限：未登录不能访问
    print("== 权限：未登录重定向 ==")
    c2 = app.test_client()
    r = c2.get("/admin/novel/import", follow_redirects=False)
    check(r.status_code == 302, "未登录跳转到 login")

    print("\n导入功能全部测试通过 ✅")


if __name__ == "__main__":
    main()
