# 我的小站

一个基于 Flask 的个人站点 + 小说站，支持：**账号体系 / 文章 / 小说章节 / 评论 / 阅读量 / Markdown / 全文搜索 / 文件上传**，UI 使用 Tailwind CSS。

## 功能一览

| 模块 | 说明 |
|------|------|
| 账号 | 注册 / 登录 / 登出 / 修改密码；admin 首次登录强制改密 |
| 文章 | 所有登录用户可发布、编辑自己的文章；admin 可删除 |
| 小说 | admin 创建小说、管理章节（序号排序、上下章导航） |
| 评论 | 文章 / 小说支持 Markdown 评论 |
| 阅读量 | 文章 / 小说 / 章节分别统计 |
| **搜索** | 全文检索文章 / 小说 / 章节（含章节正文），支持范围筛选 |
| **上传** | 登录用户可上传文件（白名单类型、20MB 上限），可下载 / 删除自己的 |

## 快速开始（Termux / Linux）

```bash
cd site
bash setup.sh                # 一键：venv → 依赖 → 密钥 → 建库 → 测试 → 启动
# 或开发模式
python3 app.py
```

浏览器访问 `http://[你的IPv6]:8080`（用 http，不是 https）。

默认管理员：`admin / admin123`（首次登录会强制改密）。

## 手动验证

```bash
python3 run_tests.py         # 运行 test_site.py + verify.py
```

测试使用临时数据库，不会污染你的真实数据。

## 目录结构

```
site/
├── app.py                # 主程序（路由 / 鉴权 / 搜索 / 上传）
├── templates/            # Jinja2 模板（base + 各页面）
├── requirements.txt
├── setup.sh              # 一键部署
├── test_site.py          # 功能测试（账号/文章/小说/搜索/上传/鉴权）
├── verify.py             # 持久化验证（重启后数据完整）
├── run_tests.py          # 一键运行全部测试
└── instance/uploads/      # 用户上传文件（运行时生成，不入库）
```

## 搜索接口

- URL：`/search?q=<关键词>&scope=<all|posts|novels|chapters>`
- 关键词至少 2 个字符
- 顶栏搜索框可直接使用

## 上传说明

- 允许类型：png / jpg / gif / webp / pdf / txt / md / docx / xlsx / zip / mp3 / mp4
- 单文件上限 20MB（可在 `app.py` 的 `MAX_CONTENT_LENGTH` 调整）
- 文件存储于 `instance/uploads/`，数据库记录原始文件名便于下载
- **生产环境建议**：用 Nginx / X-Accel 托管上传目录，或将文件存对象存储

## 上线前必做

1. 修改默认密码 `admin / admin123`
2. **密码哈希化**：当前为演示（明文），正式部署请改用 `werkzeug.security.generate_password_hash`
3. **加 HTTPS**：推荐使用 Cloudflare Tunnel（见 `CLOUDFLARED.md`），免暴露公网端口
4. 用完即关 `pkill -f gunicorn`，不要长期裸暴露 8080
5. `SECRET_KEY` 用环境变量覆盖默认值

## 安全说明

- 所有写操作（发布 / 编辑 / 删除 / 上传）均需登录，admin 操作需权限
- 文件上传做了扩展名白名单 + UUID 重命名，防止目录穿越与执行
- 删除文件同时清理磁盘文件与数据库记录

## 许可

仅用于学习与个人使用。
