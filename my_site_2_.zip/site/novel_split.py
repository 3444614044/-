# -*- coding: utf-8 -*-
"""把一本 txt/md 拆成 [(number, title, body), ...]。

章节头判定（命中即作为新章节起点）：
  • 第X章 / 第X节 / 第X卷 / 第X篇 / 第X部分
  • Chapter N / Part N
  「第X章」后若紧跟标题文字（无论有无标点分隔）→ 提取为标题；
  「第X章」后若无任何文字（整行就是"第一章"）→ 用整行作标题。

序号行（弱信号，要求本行≤30字符且有标题）：
  • 1. 标题 / 01 标题 / (1) 标题 / [1] 标题

不拆分（归入正文）：
  • 裸「卷二」「篇三」等无"第"前缀的独立分组标记。

兜底：以上都不命中 → 整份当作单章，标题取书名。

导出 split_novel(text, title) 供路由使用。
"""
import re

_CN_NUM = r"[\d〇一二三四五六七八九十百千万壹贰叁肆伍陆柒捌玖拾佰仟萬]"

# 「第」+ 数字 + 类别词（章/节/卷/篇/部分）+ 其后任意内容
_HEAD = re.compile(
    rf"^\s*第\s*{_CN_NUM}+\s*"
    r"(章|节|卷|篇|部分)"
    r"(.*)$",
    re.IGNORECASE,
)
# Chapter / Part + 数字 + 其后任意内容
_EN = re.compile(
    r"^\s*(?:Chapter|Part)\s*[\dIVXLCDM]+\s*(.*)$",
    re.IGNORECASE,
)
# 序号行（弱信号）
_NUM = re.compile(
    r"^\s*(?:\(?\d{1,3}\)?|\[\d{1,3}\]|"
    rf"{_CN_NUM}+)\s*[\.、。\-]\s*(.+)$"
)


def _clean(line: str) -> str:
    return line.strip().lstrip("#").strip()


def _strip_leading(seg: str) -> str:
    """去掉行首的章节序号标记，留下标题。如「 启程」→「启程」。"""
    seg = seg.strip()
    # 去掉开头的标点/空格分隔符
    seg = re.sub(r"^[：:：\-—\s]+", "", seg)
    return seg.strip()


def _head_title(line: str):
    """若是章节头则返回标题（可能为空串表示"用整行"），否则 None。"""
    s = line.strip().lstrip("#").strip()  # 兼容 Markdown 标题标记 `# 第X章`
    if not s:
        return None
    m = _HEAD.match(s)
    if m:
        rest = (m.group(2) or "").strip()
        if not rest:
            return s  # 整行就是"第一章"，无标题
        return _strip_leading(rest) or s
    m = _EN.match(s)
    if m:
        rest = (m.group(1) or "").strip()
        if not rest:
            return s
        return _strip_leading(rest) or s
    # 序号行（弱信号：需有标题、本行短）
    m = _NUM.match(s)
    if m and m.group(1).strip() and len(s) <= 30:
        return m.group(1).strip()
    return None


def split_novel(text: str, fallback_title: str = "正文") -> list:
    """返回 [{"number": int, "title": str, "body": str}, ...]"""
    lines = text.splitlines()
    cur_title = None
    cur_body = []
    chapters = []

    def push():
        if cur_title is None and not any(l.strip() for l in cur_body):
            return
        title = (cur_title or fallback_title).strip() or fallback_title
        # 去掉与标题完全一样的行，避免标题在正文重复出现
        body_lines = [l for l in cur_body if l.strip() != title]
        body = "\n".join(body_lines).strip()
        if not body and cur_title:
            body = title
        chapters.append({"title": title, "body": body})

    for raw in lines:
        title = _head_title(raw)
        if title is not None:
            push()
            cur_title = _clean(title) or raw.strip()
            cur_body = []
        else:
            cur_body.append(raw)

    push()

    # 规范化：过滤空章节，连续重新编号
    out = []
    idx = 0
    for ch in chapters:
        if not ch["body"].strip() and ch["title"] == fallback_title:
            continue
        idx += 1
        out.append({"number": idx, "title": ch["title"], "body": ch["body"]})
    return out


if __name__ == "__main__":
    for c in split_novel(
        """第一章 启程
星尘号缓缓升空。

第二章 深空
前方是未知的星海。

第三章：归来
一切都值得。
""",
        "星尘之旅",
    ):
        print(c)
